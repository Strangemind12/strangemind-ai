# Strangemind AI
A 24/7 WhatsApp Business AI bot for movies, food, games, and more.